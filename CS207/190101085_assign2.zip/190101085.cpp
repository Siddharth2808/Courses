#include<bits/stdc++.h>
using namespace std;
void solve(long long a)
{
    vector<pair<string,long long>> input;
    for(long long i=1; i<=a; i++){
        string temp1;long long temp2;
        cin>>temp1>>temp2;
        input.push_back(make_pair(temp1,temp2));
    }
    if(a==1){int ans1=0;cout<<"The max node weighted independent set (IS) in this chain graph of " << a <<" nodes is : \n";
        if(input[0].second >= 0)
        {
            ans1+=input[0].second;
            cout<<input[0].first<<" "<<input[0].second<<"\n";
        }
        
        cout<<"And maximum total weightage is : "<<ans1<<" .\n";
    }
    else{
    vector<long long> weight; long long now[a],last[a],temp[a];
    for(int i=0;i<a;i++)
    {
        now[i]=-1;last[i]=-1;temp[i]=-1;
    }
    
    for(auto x:input)
    {weight.push_back(x.second);}
    long long ans[a];
    ans[0]=weight[0];now[0]=1;
    
    ans[1]=max(weight[0],weight[1]);last[0]=1;
     if(weight[0]<weight[1]) now[0]=2;
    
    
    for(long long i=2;i<a;i++)
    { ans[i]=max(ans[i-1],ans[i-2]+weight[i]);
    
            for(int j=0;last[j]!=-1;j++)
            {
                temp[j]=last[j];
            }
            for(int j=0;now[j]!=-1;j++)
            {
                last[j]=now[j];
            }
    
        if(ans[i-1]<weight[i]+ans[i-2])
        {   int j=0;
            for(;temp[j]!=-1;j++)
            {
                now[j]=temp[j];
            }
            now[j]=i+1;
        }
    }
    cout<<"The max node weighted independent set (IS) in this chain graph of " << a <<" nodes is : \n";
    for(long long i=0;now[i]!=-1;i++)
    {    if(input[now[i]-1].second<0) {ans[a-1]-=input[now[i]-1].second;continue;}
        cout<<input[now[i]-1].first<<" "<<input[now[i]-1].second<<"\n";
    }
    cout<<"And maximum total weightage is : "<<ans[a-1]<<" .\n";}
    
}
int main()
{
    long long a;
    cin>>a;
    solve(a);
    return 0;
}