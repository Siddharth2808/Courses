#include "llvm/Pass.h"
#include "llvm/IR/Module.h"
#include "llvm/Demangle/Demangle.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/Function.h"
#include "llvm/ADT/StringRef.h"

using namespace llvm;

namespace {
 struct CountOp : public ModulePass {
 static char ID;
 CountOp() : ModulePass(ID) {}
 
 
 bool runOnModule(Module &M) override {
 
 raw_ostream *out = &outs();
 std::error_code EC;
 out = new raw_fd_ostream("Q2.txt", EC);
 Function::iterator mx = M.begin()->begin();
 

 int max = 0, cnt = 0;
 for(Module:: iterator F = M.begin(); F!=M.end();F++)
 {
    for(Function:: iterator blocks = F->begin(); blocks!=F->end();blocks++)
    {
        for(BasicBlock::iterator i = blocks->begin(), e = blocks->end(); i!=e ;++i) cnt++;
        if(max < cnt)
        {
            max = cnt;
            mx = blocks;
        }
        cnt = 0;
    }
 }
 
 errs()<<"The Biggest Basic Block is "<< &mx<< ", it has " << max<< " instructions\n";
 errs()<<"Code for it is given in separate file\n";

 BasicBlock::iterator i = mx->begin(), e = mx->end();
 for(; i!=e;++i) *out<< *i<< "\n";
 return false;
 }
};
}

char CountOp::ID = 0;
static RegisterPass<CountOp> X("opCounter", "Assignment1", false, true);
