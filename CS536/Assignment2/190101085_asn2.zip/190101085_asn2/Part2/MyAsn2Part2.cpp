#include "llvm/Pass.h"
#include "llvm/IR/Module.h"
#include "llvm/Demangle/Demangle.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/IR/Function.h"
#include "llvm/ADT/StringRef.h"
#include <bits/stdc++.h>

using namespace llvm;

namespace {
 struct CountOp : public ModulePass {
 static char ID;
 CountOp() : ModulePass(ID) {}
 
 
 bool runOnModule(Module &M) override {
    enum sys::fs::OpenFlags F_None;
    std::error_code EC;
    raw_fd_ostream dut("Q2.dot",EC,F_None);
 
 //raw_ostream *dut = &outs();
// std::error_code EC;
 //dut = new raw_fd_ostream("Q2.dot", EC);
 
 Function::iterator mx = M.begin()->begin();
 

 int max = 0, cnt = 0;
 for(Module:: iterator F = M.begin(); F!=M.end();F++)
 {
    for(Function:: iterator blocks = F->begin(); blocks!=F->end();blocks++)
    {
        for(BasicBlock::iterator i = blocks->begin(), e = blocks->end(); i!=e ;++i) cnt++;
        if(max < cnt)
        {
            max = cnt;
            mx = blocks;
        }
        cnt = 0;
    }
 }
 
 errs()<<"The Biggest Basic Block is "<< &mx<< ", it has " << max<< " instructions\n";
 errs()<<"Code for it is given in separate file....\n";
 
 std::unordered_map<std::string, int> umap;

 BasicBlock::iterator i = mx->begin(), e = mx->end();
 dut << "digraph G { \n";
 for(; i!=e;++i)
 {
    int temp= i->getNumOperands();
     if(i->getOpcodeName() == "store") 
     {
         dut << i->getOperand(1)->getNameOrAsOperand() << " -> " <<i->getOpcodeName()<<"\n";
         dut <<i->getOpcodeName() << " -> " << i->getOperand(1)->getNameOrAsOperand()<<"\n";
     }
     else
     {
     for(int j=0;j<temp;j++)
      {
        std::string s= i->getOperand(j)->getNameOrAsOperand();
        std::string t = i->getOpcodeName();
        std::string u = i->getNameOrAsOperand();
        for(int i = 0;i<s.size();i++)
        {
          if(s[i] == '%' || s[i] == '.' || s[i] == '<' || s[i] == '>') {s[i] = 'z';}
         if(s[i] == '+') {s = s.substr(0, i);break;}
        }
        
        for(int i =0;i<t.size();i++)  {if(t[i] == '%' || t[i] == '.' || t[i] == '<' || t[i] == '>') {t[i] = 'z';}}
         for(int i =0;i<u.size();i++)  {if(u[i] == '%' || u[i] == '.' || u[i] == '<' || u[i] == '>') {u[i] = 'z';}}
        
         if(s.size()>15) s = s.substr(0, 15);
         if(t.size()>15) t = t.substr(0, 15);
         if(u.size()>15) u = u.substr(0, 15);
         if(s[0] >= '0' && s[0]<='9') s[0] = s[0] + ('a' - '0');
         
         umap[t]++;
         
         t+=std::__cxx11::to_string(umap[t]);
         std::string ans1 = s + "-> " + t + "\n";
         std::string ans2 = t + "-> " + u + "\n";
         if(ans1.size()>1) dut<<ans1;
         if(ans2.size()>1) dut<<ans2;
      }
     }
 }
   dut << "}";
 return false;
 }
};
}


char CountOp::ID = 0;
static RegisterPass<CountOp> X("opCounter", "Assignment1", false, true);
