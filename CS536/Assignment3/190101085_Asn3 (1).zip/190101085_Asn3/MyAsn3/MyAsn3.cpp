#include "llvm/ADT/Statistic.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/Module.h"
#include "llvm/Pass.h"
#include "llvm/Support/raw_ostream.h"

using namespace llvm;

//#define DEBUG_TYPE "MyAsn3"

namespace {

struct MyAsn3 : public ModulePass {
  static char ID; 
  MyAsn3() : ModulePass(ID) {}

  virtual bool runOnModule(Module &M) override {
    errs()<<"Process Begun\n";
    Function *printll = nullptr, *printss = nullptr;

    auto i = 1;
    for (Function &f : M) {
      auto nameOp = f.getName();
      i++;
       errs()<<"Inside Function " << f.getName() << "\n";
      if (nameOp.find("printLL") != std::string::npos) printll = &f;
      else if (nameOp.find("printSS") != std::string::npos) printss = &f;
    }
    
    for (Function &f : M) {
      auto nameOp = f.getName();
      if (nameOp.find("printLL") != std::string::npos || nameOp.find("printSS") != std::string::npos) continue;
      
      for (BasicBlock &bb : f) {
        for (Instruction &istr : bb) {
          std::string temp1 = "load";
          std::string temp2 = "store";
          std::string temp3 = istr.getOpcodeName();
          if (temp3 == temp1) {
            auto fun_name = printll->getFunctionType()->getParamType(0); 
            auto operand = istr.getOperand(0);
            
            Instruction* it=istr.getNextNode();
            IRBuilder<> itrir(it);
            
             auto pass1 = itrir.CreatePointerCast(operand, fun_name);
            auto fun_tt = printll->getFunctionType();
            
            itrir.CreateCall(fun_tt, printll, {pass1});

          } 
          
          else if (temp3 == temp2) {
            auto fun_name = printss->getFunctionType()->getParamType(0);
            auto operand = istr.getOperand(1);
          
            Instruction* it=istr.getNextNode();
            IRBuilder<> itrir(it);
            
            auto pass1 = itrir.CreatePointerCast(operand, fun_name);
            auto fun_tt = printss->getFunctionType();
            
            itrir.CreateCall(fun_tt, printss, {pass1});
          }
        }
      }
    }
    enum sys::fs::OpenFlags F_None;
    std::error_code EC;
    raw_fd_ostream file("final.ll", EC, F_None);
    file << M;
    errs()<<"Process Completed\n";
    return false;
  }
};
} 

char MyAsn3::ID = 0;
static RegisterPass<MyAsn3> X("MyAsn3", "Pass to count functions and arity");