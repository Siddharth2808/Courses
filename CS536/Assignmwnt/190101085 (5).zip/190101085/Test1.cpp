int addop (int a, int b)
{
a= 5;
if(a==5) a = 6;
  return a + b;
}

void minus()
{
   return;
}
