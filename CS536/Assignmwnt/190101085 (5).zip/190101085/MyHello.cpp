#include "llvm/Pass.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Function.h"
#include "llvm/Support/raw_ostream.h"
#include <map>
using namespace llvm;

namespace {
 struct CountOp : public ModulePass {
 int count1 = 0, count2 = 0, count3 = 0;
 static char ID;
 CountOp() : ModulePass(ID) {}
 
 
 virtual bool runOnModule(Module &M) {
 
 
 for(auto &F: M){
 count1++;
 count3 = F.arg_size();
 errs() << "Function " << count1 <<" "<<F.getName() << '\n';
 
 for (auto &i: F) {
      count2++;
 }
  errs() << "Number of Arguments " << count3 << '\n';
  errs() << "Number of Basic blocks " << count2 << '\n';
  count2 = 0;
 }
 
 

 errs()<<"\n Number of Functions "<<count1<<"\n";
 return false;
 }
 
 };
}


char CountOp::ID = 0;
static RegisterPass<CountOp> X("opCounter", "Assignment1", false, true);
