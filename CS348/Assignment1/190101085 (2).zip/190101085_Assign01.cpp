//Compile on g++/ gcc compiler.
//Siddharth Charan
//Roll Number:190101085

#include<bits/stdc++.h>
using namespace std;    

unordered_map<string,string> instrTable,symtable;
unordered_map<char, long long> hexToDec; 
unordered_map<long long, char> decToHex;  
string LOCCTR, starting_address, program_length;
char Buffer[256];

string decimalToHex(long long n) //Function to change decimal Number to hex
{    
    string res ="";  
    while(1) 
    {if(n!=0) {int temp = n%16;res = decToHex[temp] + res; n/=16;} else break; } 
    return res;
} 

long long hexToDecimal(string hexaNumber)//Function to change hex to decimal number
{
	long long temp = 1, power = hexaNumber.length(), checkLength = hexaNumber.length()-temp+1, decimalResult = 0;
	for (long long i = 0; i <= hexaNumber.length()-1; i++)
	{
	    power--;
		if (int(hexaNumber[i]) >= '0' && int(hexaNumber[i]) <= '9')                 // if FirstHexaNumber 0 to 9
		{decimalResult = ((hexaNumber[i] - '0')) * pow(16, power*temp) + decimalResult;}
		
		else if (int(hexaNumber[i]) >= 'a' && int(hexaNumber[i]) <= 'f')			// if FirstHexaNumber is A to F
		{decimalResult = (((hexaNumber[i]) - 'a') + 10)* pow(16*temp, power) + decimalResult;}
		
		else			// if FirstHexaNumber is A to F
		{decimalResult = (((hexaNumber[i]) - 'A') + 10)* pow(16, power*temp) + decimalResult;}
		
	}
	return decimalResult;
}

string addTwoHexStr(string a, string b) //Function to add two hex numbers
{ 
	return decimalToHex(hexToDecimal(a) + hexToDecimal(b));
} 

string optab_retrieve(string key)//This function helps to retrive entry from optable
{
    if(instrTable.find(key)==instrTable.end()) return "-1";
    return instrTable[key];
}

string symtab_retrieve(string label){//This function helps to retrive entry from symtable
    if(symtable.find(label)==symtable.end()) return "-1";
    return symtable[label];
}

void instrTable_intializer(){
    instrTable["ADD"] = "18";
    instrTable["AND"] = "40";
    instrTable["COMP"] = "28";
    instrTable["DIV"] = "24";
    instrTable["J"] = "3C";
    instrTable["JEQ"] = "30";
    instrTable["JGT"] = "34";
    instrTable["JLT"] = "38";
    instrTable["JSUB"] = "48";
    instrTable["LDA"] = "00";
    instrTable["LDCH"] = "50";
    instrTable["LDL"] ="08" ;
    instrTable["LDX"] = "04";
    instrTable["MUL"] ="20" ;
    instrTable["OR"] = "44";
    instrTable["RD"] = "D8";
    instrTable["RSUB"] = "4C";
    instrTable["STA"] = "0C";
    instrTable["STCH"] = "54";
    instrTable["STSW"] = "E8";
    instrTable["STL"] = "14";
    instrTable["STX"] = "10";
    instrTable["SUB"] = "1C";
    instrTable["TD"] = "E0";
    instrTable["TIX"] = "2C";
    instrTable["WD"] = "DC";
}

bool pass1(ifstream& fin, ofstream& fout1, ofstream& fout2)
{
    string opcode,intermediate,operand,temp_line,loc,label, tokens[10][2];
    long long i = 0, j = 0, len = 0, sure = 0;
    
    FILE* fptr;
    fptr = fopen("input.asm","rw");
    fout1.open("intermediate_file.txt");
    
    // read first input line
    temp_line = fgets(Buffer,256,fptr);
    temp_line.pop_back(); 
    
    // Using this while loop to store values of opcode, operand  and label in array tokens
    while(1) {
    if(j==temp_line.size()) {tokens[i][0] = intermediate; intermediate = ""; i++;break;}
    else if(temp_line[j]==' ') {tokens[i][0] = intermediate; intermediate = ""; i++;}
    else intermediate += temp_line[j]; 
        j++;
    } i = 0; j = 0;
    
    //if this is not a comment
    if(tokens[0][0] != ".")
    {
    	opcode = tokens[1][0];
    	operand = tokens[2][0];
    }
    label = tokens[0][0];
    
    
    // If opcode is not "START", then LOCTOR is set to 0
    if(opcode!="START")
    {
        starting_address="0";
        LOCCTR="0";
    }        
    else //  starting_address is initialized to LOCCTR
    {
        starting_address = operand; // save operand as starting address
        LOCCTR = starting_address; // initialize LOCTOR to starting_address 
        fout1<<LOCCTR<<"\t"<<label<<"\t"<<opcode<<"\t"<<operand<<"\n"; // write line to intermediate file
    }

    //Starting of while loop, to fetch next lines of data from input file
    while(1)
    {   // read next input line
        temp_line = fgets(Buffer,256,fptr);
        temp_line.pop_back();
        sure = 0;
        
        // fetching label, opcode, operand from first input line

	    while(1) {
        if(j==temp_line.size()) {tokens[i][0] = intermediate; intermediate = ""; i++;break;}
        else if(temp_line[j]==' ') {tokens[i][0] = intermediate; intermediate = ""; i++;}
        else intermediate += temp_line[j]; 
        j++;
        } i = 0; j = 0;
        
        loc=LOCCTR;

	    if(tokens[0][0] != ".")
        {
    	    opcode = tokens[1][0];
    	    operand = tokens[2][0];
        }
        label = tokens[0][0];

        if(opcode[0]=='E' && opcode[1]=='N' && opcode[2]=='D' && sure == 0) {sure = 1;break;}
        if(temp_line[0]=='.') continue;
        
        // if this is not comment line
        if(label!="**")
        {
                // search SYMTAB for LABEL
                // if found
                if(symtable.find(label)!=symtable.end())
                {
                    printf("Pay Attention, error case::");
                    printf("Symbol is repeated\n");
                }
                else{
                    // insert (LABEL,LOCTOR) into SYMTAB
                    string temp = label;
                    symtable[temp] = LOCCTR; 
                }
        }
        sure = 1;
        char hex_string[50];
            // search OPTAB for OPCODE
            //The case when opcode == word , is also similar
        if(instrTable.find(opcode)!=instrTable.end() || (opcode[0]=='W' && opcode[1]=='O' && opcode[2]=='R' && opcode[3]=='D') )  
                LOCCTR = addTwoHexStr(LOCCTR,"3");
            //if opcode == RESW
        else if(opcode[0]=='R' && opcode[1]=='E' && opcode[2]=='S' && opcode[3]=='W')
                LOCCTR = addTwoHexStr(LOCCTR,to_string(3*sure*stoi(operand)));
            //If opcode == RESB
        else if(opcode[0]=='R' && opcode[1]=='E' && opcode[2]=='S' && opcode[3]=='B'){
                sprintf(hex_string, "%X", stoi(operand));
                LOCCTR=addTwoHexStr(LOCCTR,hex_string);
        }
            //If opcode == BYTE
        else if(opcode[0]=='B' && opcode[1]=='Y' && opcode[2]=='T' && opcode[3]=='E')
        {
                if(operand[0]=='X') LOCCTR = addTwoHexStr(LOCCTR,to_string((operand.length()-3)/2));
                else LOCCTR = addTwoHexStr(LOCCTR,to_string((operand.length()-3)));
        }
        //Remaining, error case
        else 
        {printf("Kindly note that");
         printf(": You have entered invalid code!!!\n");
         }
        fout1<<loc<<"\t"<<label<<"\t"<<opcode<<"\t"<<operand<<"\n";
    }
    sure = -1;
    program_length = decimalToHex(hexToDecimal(LOCCTR)+ (sure*hexToDecimal(starting_address)));
    fout1<<"**\t"<<label<<"\t"<<opcode<<"\t"<<operand<<"\n";

    fclose(fptr);
	fout1.close();
    printf("Pass1 Successfully Completed\n");
    return true;
}

bool pass2(ifstream& fin, ofstream& fout1, ofstream& fout2)
{
	string tokens[10][2],first_address,prog_name,temp_line,obj_code,txt_record,intermediate,ss = "";
    char ch;
    int txt_record_length=0,incr=0,i=0,j=0,cnt = 1, RES;
    stringstream text_ss(txt_record),obj_ss(obj_code);

    FILE* fptr;
    fout1.open("object_codes.txt");
    fout2.open("output.o");
    fptr = fopen("intermediate_file.txt","rw");

    temp_line = fgets(Buffer,256,fptr);
    temp_line.pop_back(); 

    while(1) {
    if(j==temp_line.size()) {tokens[i][0] = intermediate; intermediate = ""; i++;break;}
    else if(temp_line[j]=='\t') {tokens[i][0] = intermediate; intermediate = ""; i++;}
    else intermediate += temp_line[j]; 
        j++;
    } i = 0; j = 0;
    
    string address=tokens[0][0],label=tokens[1][0],opcode=tokens[2][0],operand=tokens[3][0];
    prog_name = tokens[1][0];
    ss+=ch;
    if(opcode=="START")
	{
		fout1<<address<<"\t"<<label<<"\t"<<opcode<<"\t"<<operand<<"\n";
        temp_line = fgets(Buffer,256,fptr);
    	temp_line.pop_back(); 

	    while(1) {
        if(j==temp_line.size()) {tokens[i][0] = intermediate; intermediate = ""; i++;break;}
        else if(temp_line[j]=='\t') {tokens[i][0] = intermediate; intermediate = ""; i++;}
        else intermediate += temp_line[j]; 
        j++;
        } i = 0; j = 0;
	    address = tokens[0][0];label = tokens[1][0];opcode = tokens[2][0];operand = tokens[3][0];
	}

    //write header record to object program
	fout2<<"H^"<<prog_name<<"\t"<<"^"<<setw(6)<<setfill('0')<<starting_address<<"^"<<setw(6)<<setfill('0')<<program_length<<"\n";
    first_address = address;
    cnt=1-cnt;
    ss="";
    
    //While loop started
    while(opcode!="END")
	{
	    //If opcode == END then break,
	    //or in comment case also, as it is an error case if a comment remains in intermediate_file
        if(opcode[0]=='E' && opcode[1]=='N' && opcode[2]=='D' || label == ".") break;
        // if this is not comment line
		if(instrTable.find(opcode)!=instrTable.end())    // if found
		{
		        if(operand == "**"){
                        obj_ss << optab_retrieve(opcode)<<"0000";
                    }
                // if there is a symbol in the operand field  
				if(operand!="**") 
				{
				    int size = operand.size();
					string actual_operand = "";
					long relative=0;
					for(int i=0;i<=size-3;i++)
					{
						actual_operand+=operand[i];
				 		if(operand[i+1]==',' && operand[i+2]=='X') 	{relative=1;	break;}
					}
					if(relative==1)
					{
                        if(symtable.find(actual_operand)!=symtable.end())  // search symtab for actual operand
						{
                            obj_ss << optab_retrieve(opcode)<<setw(4)<<setfill('0')<<addTwoHexStr(symtab_retrieve(actual_operand),"8000");
						}
						else
						{
						    string zeroes = "0000";
                            obj_ss << optab_retrieve(opcode)<<zeroes;
                            printf("Invalid opcode entered\n");
                        }
					}
					else if(symtable.find(operand)!=symtable.end())
                    {
                        obj_ss << optab_retrieve(opcode)<<setw(4)<<setfill('0')<<symtab_retrieve(operand);
                    }
					else//Error Case
					{string zeroes = "0000";
                        obj_ss << optab_retrieve(opcode)<<zeroes;
                        printf("Kindly note that this is an Invalid operand\n");
					}
				}
				incr=3;
		}
		else
		{
		        if(operand[0]=='C')
				{ incr=operand.length()-3;
                    for(int i=2;i<operand.size()-1;i++)
                    {
                         obj_ss<<decimalToHex((int)operand[i]);
                    }
				}
				else if(operand[0]!='C' && operand[0]=='X')
				{ incr=(operand.length()-3)/2;
                   for(int i=2;i<operand.size()-1;i++)
                     {
                        obj_ss<<(char)(operand[i]);
                     }
				}
				if(operand[0]!='C' && operand[0]!='X') {  incr=3; obj_ss<<setw(6)<<setfill('0')<<decimalToHex(stoi(operand)); }
		}
		txt_record_length=incr+txt_record_length;
		//Case when text_record is full
		if(txt_record_length>=31)
		{
                fout2<<"T^"<<setfill('0')<<setw(6)<<first_address<<"^"<<setfill('0')<<setw(2)<<decimalToHex(txt_record_length-incr)<<text_ss.str()<<"\n";
                text_ss.str("");
                first_address = address;
                txt_record_length=incr;
		}
		text_ss<<"^"<<obj_ss.str();
        
		fout1<<address<<"\t"<<label<<"\t"<<opcode<<"\t"<<operand<<"\t"<<obj_ss.str()<<"\n";
        obj_ss.str("");

        temp_line = fgets(Buffer,256,fptr);
	    temp_line.pop_back(); 

	    while(1) {
        if(j==temp_line.size()) {tokens[i][0] = intermediate; intermediate = ""; i++;break;}
        else if(temp_line[j]=='\t') {tokens[i][0] = intermediate; intermediate = ""; i++;}
        else intermediate += temp_line[j]; 
        j++;
    } i = 0; j = 0;
        address = tokens[0][0];label = tokens[1][0];opcode = tokens[2][0];operand = tokens[3][0];

		RES=0;
		if(opcode=="RESW"||opcode=="RESB")
		{
 			fout2<<"T^"<<setw(6)<<setfill('0')<<first_address<<"^"<<setw(2)<<setfill('0')<<decimalToHex(txt_record_length)<<text_ss.str()<<"\n";
			text_ss.str("");
			txt_record_length=0;
		}
		while(opcode=="RESW"||opcode=="RESB")
		{
			fout1<<address<<"\t"<<label<<"\t"<<opcode<<"\t"<<operand<<"\n";
            temp_line = fgets(Buffer,256,fptr);
		    temp_line.pop_back(); 

		    while(1) {
            if(j==temp_line.size()) {tokens[i][1] = intermediate; intermediate = ""; i++;break;}
            else if(temp_line[j]=='\t') {tokens[i][1] = intermediate; intermediate = ""; i++;}
            else intermediate += temp_line[j]; 
            j++;
            } i = 0; j = 0;
		    address = tokens[0][1];label = tokens[1][1];opcode = tokens[2][1];operand = tokens[3][1];

			RES=1;
		}
		if(RES)
			first_address=address;
	}
    //end of while
	if(!RES){
    	fout2<<"T^"<<setfill('0')<<setw(6)<<first_address<<"^"<<setfill('0')<<setw(2)<<decimalToHex(txt_record_length)<<text_ss.str()<<"\n";
    }
		fout1<<address<<"\t"<<label<<"\t"<<opcode<<"\t"<<operand<<"\t";
		fout2<<"E^"<<setfill('0')<<setw(6)<<starting_address;
        
        fout2.close();
        fclose(fptr);
		fout1.close(); 
		
        printf("Pass2 Successfully completed\n");
        return true;
}

int main()
{
    printf("Compilation, of the code started!!!\n");
   ifstream fin;
   ofstream fout1,fout2;
   instrTable_intializer();
   //Inserting values in unordered_map hexToDec
   hexToDec.insert({{'3', 3},{'7', 7},{'8', 8},{'9', 9},
        {'A', 10},{'B', 11},{'0', 0},{'1', 1},{'4', 4},{'5', 5},{'6', 6},{'2', 2},{'C', 12 },{'D', 13},{'E', 14},{'F', 15}});
   //Inserting values in unordered_map decToHex
   decToHex.insert({{5, '5'},{6, '6'},{7, '7'},{12,'C'},{8, '8'},{9, '9'},
        {10,'A'},{11,'B'},{3, '3'},{4, '4'},{13,'D'},{0, '0'},{1, '1'},{2, '2'},{14,'E'},{15,'F'}});
    pass1(fin,fout1,fout2);
    pass2(fin,fout1,fout2);
    printf("Compilation of the code completed\n");
	return 0;
}