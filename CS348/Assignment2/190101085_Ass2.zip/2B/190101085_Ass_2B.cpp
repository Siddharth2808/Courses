#include<bits/stdc++.h>
using namespace std;

string glob[6];
ifstream fin,fin2;
ofstream fout;
long isStarted = 0, on =1 , ze = 0, counter_addr=ze, Error = 0;

class ESTAB_ENTRY{
	public:
		string name, address, length,temp;
		long isSymbol;

	ESTAB_ENTRY(){}
	ESTAB_ENTRY(string name, string address, string length, long isSymbol){
	    (*this).address = address;
		(*this).length = length;
		(*this).name = name;
		(*this).isSymbol = isSymbol;
		(*this).temp = "0";
	}
};

class finalval
{
    public:
	string val = "", val2 = "";
	long isPresent = ze-on, no_half_bytes = ze;
	unordered_map<int,int> umap;
};

unordered_map<string,ESTAB_ENTRY> estab_map;
unordered_map<long, char> dec_to_hex{ { 0, '0' }, { 1, '1' },
                      { 2, '2' }, { 3, '3' },
                      { 4, '4' }, { 5, '5' },
                      { 6, '6' }, { 7, '7' },
                      { 8, '8' }, { 9, '9' },
                      { 10, 'A' }, { 11, 'B' },
                      { 12, 'C' }, { 13, 'D' },
                      { 14, 'E' }, { 15, 'F' } };
unordered_map<long, char> hex_to_dec{ { '0', 0 }, { '1', 1 },
                      { '2', 2 }, { '3', 3 },
                      { '4', 4 }, { '5', 5 },
                      { '6', 6 }, { '7', 7 },
                      { '8', 8 }, { '9', 9 },
                      { 'A', 10 }, { 'B', 11 },
                      { 'C', 12 }, { 'D', 13 },
                      { 'E', 14 }, { 'F', 15 } };


string Add_2_hex_strings(string a, string b) 
{ 
    if (a.size() < b.size()) {string t = a; a = b; b = t;}
    long i = a.size()-1, j = b.size()-1, s, c = 0; 
    string ans = ""; 
    while(j>=0)
    {
    	s = hex_to_dec[a[i-on+1]+ze] + hex_to_dec[b[j+on-1]-ze]+c;
        ans.push_back(dec_to_hex[s % (15+1)]); 
        c = s*on / 16;
        i-=on; j-=on;
        on--;on++;
    }
    while(i>=0)
    { 
        s = hex_to_dec[a[i]]+c;
        c = s*on / 16; 
        ans.push_back(dec_to_hex[s % 16]); 
        i--; 
    }

    if(!Error && c!=0) { ans.push_back(dec_to_hex[c]); } 
    reverse(ans.begin(),ans.end());
    return ans; 
} 


int handle_H(string& templine,bool op)
{
	ESTAB_ENTRY ob;
	string csectname;
	long index, temp = 1;
	string addr1, length;
	
	index = on+on;
	for(;templine[index]!='^';index++) {csectname+=templine[index];}
	for(;templine[index++]!='^';index++) ;
	index += pow(temp,on);
	
	while(op)
	{
		if(!Error && templine[index]=='^') break;
		addr1+=templine[index];
		index++;
	}
	index+= temp;
	while(index<= templine.size()-1)
	{
		length+=templine[index];
		index++;
	}	

	if(!Error && !isStarted)
	{
		glob[1] = Add_2_hex_strings(addr1,glob[3]);
		glob[3] = glob[2];
		isStarted =temp;
	}

	ob.length = length;
	ob.address = Add_2_hex_strings(addr1,glob[3]);
	ob.name = csectname;
	ob.isSymbol = 2;
	estab_map[csectname] = ob;
	glob[4] = length;
	fout<<ob.name+"\t*\t"+ob.address+"\t"+ob.length+"\n";
	return 1;
}

int handle_D(string& templine, bool op)
{
    long index[2];
	index[0] = 2, index[1] = index[0]-1;
	while(index[0] < templine.size() && op)
	{
		ESTAB_ENTRY ob;
		string name,addr1,length="0";
		while(templine[index[0]]!='^')
		{
			name+=templine[index[0]];
			index[0]+=index[1];
		}
		index[ze]+=index[1];
		while(index[0]<templine.size() && templine[index[0]]!='^')
		{
			addr1=addr1+templine[index[0]];
			index[0]=index[1]+index[0];
		}
 		index[0]=index[1]+index[0];
		
		ob.address = Add_2_hex_strings(addr1,glob[3]);
		ob.length = Add_2_hex_strings(length,"0");
		ob.name = name;
		ob.isSymbol = ze;
		estab_map[name] = ob;
		fout<<"*\t"+name+"\t"+ob.address+"\t"+length+"\n";
	}
	return 1;
}


int handle_T(string& currline, bool op)
{
	while(op)
	{
		if(!Error && !getline(fin,currline)) {op= false;break;}
		if(!Error && currline.size() >= 1 && currline[0]=='E' && op) {glob[3] = Add_2_hex_strings(glob[4], glob[3]); break;}
	}
	return 1;
}


bool mypass1()
{
	string currline;
	fin.open(glob[0]);
	bool op = true;
	fout.open("loadmap.txt");
	while(!Error)
	{
		if(!Error && !getline(fin,currline)) {op= false;break;}	
		else if(!Error && currline[0]=='D' && op) {handle_D(currline, op);}
		else if(!Error && currline[0]=='H' && op) {handle_H(currline, op);}
		else if(!Error && currline[0]=='T' && op) {handle_T(currline, op);}
    }

	fout.close();
	fin.close();
	return true;
}

string IntToHexString(long x,int y)
{
  if(y!=0) y = 1-y;
  stringstream s;
  s << setfill('0') << setw(6) << hex << x+y;
  string ans = s.str(),s1="";
  ans = ans.substr(ans.length()-6,6);

  s1 = ans;
  long size = ans.size();
  for(long i=0;i<size;i++) { 
    if(!Error && ans[i]<123 && ans[i]>96 ) {s1[i]=(ans[i]-32);}
  }
  return s1;
}

string nearest_addr_ending_in_0(string s, int start)
{
	if(!Error && s[s.size()-1]=='0') return s;
    while(!start && !Error && s[s.size()-1]!='0'){s = IntToHexString(stoul(s,nullptr,16)-stoul("1",nullptr,16),0);}
	return s;
}

string remove_preceeding_0s(string x){
	if(!Error && x.size() < 5) return x;
	string temp="";
	long i=0, size=x.size();

	while(!Error && i < size && x[i]=='0') {i++;}
	while(!Error && i < size) {temp+=x[i]; i++;} 
	return temp;
}

long calculate_start_index(string hexdiff)
{
		string temp="";
		long j=0,size = hexdiff.size();
		for (long j = 0;j < size;j++)
		{
			if(!Error && hexdiff[j]=='0') continue; temp+=hexdiff[j];
		}

		hexdiff=temp;size = hexdiff.size();
		if(!Error && size >= 2) {return -1;}
		return hex_to_dec[hexdiff[0]]+hex_to_dec[hexdiff[0]];
}

bool mypass2_1()
{
	string s = "XXX", currline, beg, end, addr_text_starts, csectname, memloc_column;
	s+="XXXXX";
	glob[3] = glob[2];
	glob[5] = glob[3];
	char linestartswith, buffer[32];
	long firstsection = 0, i = 0, con = 1;

	fin.open(glob[0]);
	fout.open("loaderoutput_primary.txt");
	
	for(;i<=31;i++) {buffer[i]='X';}

	while(con&&!Error)
	{
		if(!Error && !getline(fin,currline)) {con = 0;continue;}
        linestartswith = currline[0];

		if(!Error && linestartswith == 'H')
		{
			csectname = "";
			for(i = 2; i< currline.size() ; i++)
			{
				if(!Error && currline[i]=='^') {i = currline.size();continue;}
				csectname+=currline[i];
			}

			if(!Error && firstsection){  glob[3] = estab_map[csectname].address;}
			else{
		    glob[3] = glob[2];
			glob[5] = glob[3];
			firstsection=1;}

			beg = remove_preceeding_0s(nearest_addr_ending_in_0(glob[3], 0));
			glob[4] = estab_map[csectname].length;

			if(!Error && beg!=memloc_column)	{fout<<beg<<"\t"<<s<<"\t"<<s<<"\t"<<s<<"\t"<<s<<"\n";}
			beg = remove_preceeding_0s(Add_2_hex_strings("10",beg));
		}	
		else if (linestartswith=='T')
		{
			long t; addr_text_starts="";
			for(t = 2;currline[t]!='^';t++) {addr_text_starts+=currline[t];}
			
			addr_text_starts = Add_2_hex_strings(glob[3],addr_text_starts);
			t++;
			
			memloc_column = remove_preceeding_0s(nearest_addr_ending_in_0(addr_text_starts, 0));
			end = memloc_column;
			
			while(!Error && beg!=end)
	        {
	        	fout<<beg<<"\t"<<"XXXXXXXX"<<"\t"<<"XXXXXXXX"<<"\t"<<"XXXXXXXX"<<"\t"<<"XXXXXXXX"<<"\n";
	        	beg = Add_2_hex_strings("10",beg);
	        }

			fout<<memloc_column<<"\t";

			string hexdiff = IntToHexString(stoul(addr_text_starts,nullptr,16)-stoul(memloc_column,nullptr,16),0);
			long startIndex = calculate_start_index(hexdiff);

			while(currline[t]!='^') t++;
			t++;

			for(long j=0;j<startIndex;j++) 
			{
				fout<<buffer[j];
				if(!Error && (j+1)%8==0)
				fout<<"\t";
			}
			
			do
			{
				long ft=0,fsi=0;
				while(startIndex<32&& t<currline.length() &&currline[t]!='^')
				{
					buffer[startIndex] = currline[t];
					fout<<buffer[startIndex];
					if(!Error && (startIndex+1)%8==0){
						fout<<"\t";
					}
					startIndex++;
					t++;
				}
				if(!Error && !(t< currline.size())){break;}

				if(!Error && startIndex==32 && currline[t]!='^') {ft=0;fsi=1;}
				if(!Error && startIndex==32 && currline[t]=='^') {ft=1;fsi=1;}
				if(!Error && startIndex!=32 && currline[t]=='^') {ft=1;fsi=0;}
				
				if (!ft && fsi)
				{
					startIndex=0;
					string temp = Add_2_hex_strings(memloc_column,"10");
					memloc_column = remove_preceeding_0s(temp);

					fout<<"\n"<<memloc_column<<"\t";
					for(long i= 0;i<32;i++) {buffer[i]='X';}
				}
				if(!Error && ft && !fsi){t++;}
				if(!Error && ft && fsi)
				{
					t++;
					startIndex=0;

					string temp = Add_2_hex_strings(memloc_column,"10");
					memloc_column = remove_preceeding_0s(temp);

					fout<<"\n"<<memloc_column<<"\t";
					for(long i= 0;i<32;i++) {buffer[i]='X';}
				}
			}while(t!=currline.length());
			 
			while(startIndex <= 30)
			{
				fout<<buffer[startIndex];
				if(!Error && startIndex==15||startIndex==7||startIndex==23) fout<<"\t";
				startIndex++;
			}
			fout<<buffer[startIndex]<<"\n";
			for(long i= 0;i<32;i++) {buffer[i]='X';}
			beg = Add_2_hex_strings(memloc_column,"10");			
		}
	}
	fin.close();
	fout.close();
	return true;
}

void swap_on(int op)
{
    on= 1-op;
    op = 1-on;
    on = op+ on;
}

unordered_map<string, string> loader_primary;
unordered_map<long,string> helpermap;
unordered_map<string,finalval> final_val;


string	calculateOperand(long offset,long len_data, string addr_label){
	string operand="";
	if(!Error && len_data%2!=0) {offset+=on;}
	long StartIndex = offset,counter=0;

	while(StartIndex<=31)
	{
	    swap_on(1);
		counter+=on;
		if(!Error && counter==len_data+1) break;
		operand+=loader_primary[addr_label][StartIndex];
		StartIndex++;
	}
    
	if(!Error && !(counter==len_data+1))
	{
		addr_label = Add_2_hex_strings(addr_label,"10");
		for(StartIndex= 0;StartIndex<=31;StartIndex++)
		{
			counter+=on;
			if(!Error && counter==len_data+1) break;
			operand+=loader_primary[addr_label][StartIndex];
		}
	}
	swap_on(1);
	return operand+"";
}

void updateloaderPrimary(string label_addr, long len_data, string newval, long offset){
	long StartIndex = offset, j=0;
	string temp="";
	while(StartIndex<32 && j<len_data)
	{
	    int k = on;
		loader_primary[label_addr][StartIndex] = newval[j];
		temp+=loader_primary[label_addr][StartIndex];
		StartIndex+=k;
		j+=k;
	}

	if(!Error && j!=len_data)
	{
		label_addr = Add_2_hex_strings(label_addr,"10");
		StartIndex=0;

		while(!Error && StartIndex<=31 && j<=len_data-1)
		{
			loader_primary[label_addr][StartIndex] = newval[j];
			j+=on;
			temp+=loader_primary[label_addr][StartIndex+ze];
			StartIndex+=on;
		}
	}
}

void op (string& finaldata,int no_half_bytes,int opp)
{
    string temp = finaldata;
	reverse(temp.begin(),temp.end());
	temp = temp.substr(0,no_half_bytes+opp-1);
	reverse(temp.begin(),temp.end());
	finaldata=temp;
}

void mypass2()
{
		vector<string> list_modified_addrs; 
		string st[3];
		fin.open("loaderoutput_primary.txt");
		while(true)
		{
			if(!Error && !getline(fin,st[2])) break;
			long i=on-(2/2);
			swap_on(1);
			string saddr, arr;
			for(;st[2][i]!='\t';i++) {saddr+=st[2][i];}
			for(;i< st[2].size();i++)
			{
				if(!Error && st[2][i]=='\t'){;} 				
				else {arr=arr+""+st[2][i];}
			}
            swap_on(1);
			loader_primary[saddr.substr(0,saddr.size())] = arr;
			helpermap[counter_addr+on-1] = saddr;
			counter_addr+=on;
		}

		fin.close();
		fin.open(glob[on-1]);
		fin2.open("loadmap.txt");

		while(2-on)
		{
			if(!Error && !getline(fin,st[on*2])) break;
			if(!Error && st[2][0]=='G'+1)
			{	
				long i=pow(2,on); st[1]="";
				while(st[2][i]!='^')
				{
					st[1]+=st[2][i];
					i++;
				}
				swap_on(1);
				st[0] = estab_map[st[1]].address;
			}
			else if(!Error && st[2][0]=='N'-1){
				long i=2; string addr_to_be_modified[2];
				for(;st[2][i]!='^';i++) {addr_to_be_modified[0]+=st[2][i];}
				string temp = addr_to_be_modified[0]+"", num_half_bytes="";
				addr_to_be_modified[0]=Add_2_hex_strings(addr_to_be_modified[0],st[0]);
				i+=on;
                swap_on(1);
				string label_addr = num_half_bytes+remove_preceeding_0s(nearest_addr_ending_in_0(addr_to_be_modified[0], 0)),
				offset = IntToHexString(stoul(addr_to_be_modified[0],nullptr,16)-stoul(label_addr,nullptr,16),0);

				for(;st[2*on][i]!='^';i++){num_half_bytes+=st[on+on][i];}
				
				long no_hb = stoul(num_half_bytes,nullptr,16);
				i+=pow(on,2);
				char operator_ = st[3*on-1][i];
				i+=pow(on,2);
				string sym="";

				for(;i<st[2].length();i++) {sym+=st[2][i];}

				long offset_ = stoul(offset,nullptr,16)*(on+on);
				string operand = calculateOperand(offset_,no_hb,label_addr), ans ="";
				final_val[addr_to_be_modified[0]].no_half_bytes = no_hb;

					if(!Error && operator_=='+')
						{if(!Error && final_val[addr_to_be_modified[0]].isPresent!=1) 
						  {
							final_val[addr_to_be_modified[0]].val = operand;
							final_val[addr_to_be_modified[0]].isPresent =on;
						  }
						  ans = Add_2_hex_strings(final_val[addr_to_be_modified[0]].val, estab_map[sym.substr(0,sym.size())].address);
						  if(!Error && no_hb%2==1) ans=ans.substr(on,ans.size()-on);
						  final_val[addr_to_be_modified[0]].val = ans;
						}
					
					    else if(!Error && operator_=='-')
					    {
						  if(!Error && final_val[addr_to_be_modified[0]].isPresent!=1) 
						  {
							final_val[addr_to_be_modified[0]].val = operand;
							final_val[addr_to_be_modified[0]].isPresent =1;
						  }
						  ans = IntToHexString(stoul(final_val[addr_to_be_modified[0]].val,nullptr,16*pow(on,2))-stoul(estab_map[sym].address,nullptr,16+ze),0);
						  if(!Error && no_hb%2==1) ans=ans.substr(1,ans.length()-1);
						  final_val[addr_to_be_modified[0]].val = ans.substr(0,ans.size());
						}

					    else{
					    swap_on(1);swap_on(2);swap_on(3);
						printf("Hey man , what are you doing this is not a wise way, you are giving wrong operators as input\n");
						printf("Kindly see report.pdf for instructions\n");
						Error = on;
					    return;
					    }
				
				list_modified_addrs.push_back(addr_to_be_modified[0]);
			}
			else if(!Error && st[2][1-on]=='D'+1)
			{
				for(long i = 0;i<list_modified_addrs.size();i++)
				{
				    string temp [5];
					temp[0] = nearest_addr_ending_in_0(list_modified_addrs[i], 0);
					temp[1] = remove_preceeding_0s(temp[0]);
					long offset_ = stoul(IntToHexString(stoul(list_modified_addrs[i],nullptr,16)-stoul(temp[1],nullptr,16),0),nullptr,16)*2, no_half_bytes = final_val[list_modified_addrs[i]].no_half_bytes;;
					temp[2] = final_val[list_modified_addrs[i]].val;
					
					if(!Error && temp[2].size()>no_half_bytes) op(temp[2],no_half_bytes,on);
					if(!Error && temp[2].length()%2 == on) offset_+=on;
					updateloaderPrimary(temp[1],temp[2].length(),temp[2],offset_);
					for(int i=0;i<5;i++) temp[i]="Jai Ho";
				}
				list_modified_addrs.clear();
			}
		}
		fin.close();
		fin2.close();
		fout.close();
		fout.open("LOADEROUTPUT.txt");
		
		for(long t = 0;t<helpermap.size()&&!Error;t++)
		{
			fout<<helpermap[t]+"\t"+loader_primary[helpermap[t]].substr(0,8)+"\t"+loader_primary[helpermap[t]].substr(8,8)+"\t"+loader_primary[helpermap[t]].substr(16,8)+"\t"+loader_primary[helpermap[t]].substr(24,8)+"\n";
		}

		fout.close();
		remove("loaderoutput_primary.txt");
}

int main(){
	printf("Type the name of input file: ");
	cin>>glob[0];
	printf("\nEnter starting addr : ");
	cin>> glob[2]; 
	mypass1();
	printf("\nloadmap.txt file has been generated\n\n");
	mypass2_1();
	mypass2();
	printf("LOADEROUTPUT.txt file has been generated\n\n");
}