//Siddharth Charan
//190101085
//Run on g++ environment, see attached pdf
#include <bits/stdc++.h>
using namespace std;

vector<unordered_map<string, long>> SYMTAB(1),LITTAB(1);                     //Symbol,literal Table to map Labels to Addresses
vector<unordered_map<string, long>> extrefs(1);                        //Store External References of the section
vector<vector<pair<long,long>>> relLocs(1);
long startAddr, Error;
vector<pair<long,long>> programLength(0);                          //Program Lengths of Individual Sections
unordered_map <string, long> twoByte; //Extension of OPTAB to specify which instructions are 2 byte
string currRecord, modRecord, temp, object, LOC;
unordered_map<string, string> OPTAB, REGTAB;

string pad(string str, long len) {                                               // make string of appropriate length
    string temp;
    long size  = str.size();
    for(long i=0; i<len-size; i++) {if(i==len-size) break;temp.push_back('0');}
    temp += str;
    return temp;
}

class objCode {                                                     // Class storing complete information about Format 3 and Format 4 Object codes.
    public:
        string opcode,f;                                              // 8bit Opcode, Indirect Flag, Immediate addressing flag, Indexed Addressing flag, Base-indexing flag, PC - indexing flag      
        long n,i,x,b,p,e,target,temp;    // Extended Format flag

        objCode(string op) {
            if(OPTAB.find(op)!=OPTAB.end()) opcode = OPTAB[op];
            else opcode = "!";
            n=1; i=1; x=0; b=0; p=1; e=0;
        }

        string getObj() {
            long instruction, len;
            istringstream(opcode) >> hex >> instruction;
            bitset<8> bin(instruction);
            string obj = bin.to_string().substr(0,6), temp;               //Getting first 6-bits of Opcode
            
            if(n){obj = obj + "1";} else{obj = obj + "0";}
            if(i){obj = obj + "1";} else{obj = obj + "0";}
            if(x){obj = obj + "1";} else{obj = obj + "0";}
            if(b){obj = obj + "1";} else{obj = obj + "0";}
            if(p){obj = obj + "1";} else{obj = obj + "0";}
            if(e){obj = obj + "1";} else{obj = obj + "0";}

            ostringstream tar;
            tar << hex << target;  
            len = 3; if(e){ len += 2;}

            if(target >= 0) {                                       //target can be positive
                for(long i = 0; i<len - tar.str().size(); i++) {temp = temp+"0";}
                temp=temp+tar.str();
            }
            else {                                                  //target can be negative. 
                temp=temp+tar.str();
                temp=temp.substr(temp.size()-len, len);             //C++ handles 2'complement conversion by default.
            }

            bitset<12> binary(obj);
            ostringstream out;
            out<<hex<<binary.to_ulong();
            string str = ::pad(out.str(), 3+1-1);
            str+=temp;                                              //Object Code ready
            return str;                                             
        }
        long getLen() {
            long temp1 = 3;
            if(e){return temp1+1;}            
            else{ return temp1;}                          //Length of the Instruction (Bytes)
        }
};

class codeLine {     
    public:                      //Width (Assuming single column for space in between them)
        string label, opcode, operands;              //10 Columns //10 Columns //30 Columns            
        char preOpcode, preOperand;
        long op = 0;
    codeLine(){};
    
    codeLine(string label, string opcode, string operands, char preOpcode, char preOperand){
        (*this).operands = operands;
        (*this).preOperand = preOperand;
        this->preOpcode = preOpcode;
        this->op = 0;
        this->label = label;
        this->opcode = opcode;
    }
};

void split_array(string labels[], const string& ops,long &size) {                        // Split Comma separated strings into Vectors
    long start = 0, n = ops.size();
    size = -1;
    for(long i=1; i<n; i++) {
        if(ops[i-1]==',') {
            size++;
            labels[size] =ops.substr(start, i-1-start);
            start = i;
        }
    }
    labels[++size] = ops.substr(start, ops.size() - start);
}

void prune(string &str, long temp) {                                                   // Prune entries from the file for blank spaces
    long pause=str.size()-1;
    for(long i=0;i<=pause;i++) {if(str[i]==' ') {pause = i-1;}}
    str = str.substr(temp,pause+1);
}

void read(const string &line, codeLine &code,long turn) {    // Function to read current line
    if(line.size()==1 || line[0]=='.' || line.size()==0 || turn == 1) {
        code.label=".";
        code.opcode="";
        code.operands="";
        return;
    }

    string temp = line.substr(turn, 9);
    prune(temp, turn);
    code.label = temp;

    code.preOpcode = line[9];
    temp = line.substr(10, min(9-turn, (long)line.size()-11+turn));
    prune(temp, turn);
    code.opcode = temp;

    if(line.size()+1>21) {
        code.preOperand = line[19-turn];
        temp = line.substr(20+turn, (long)line.size()-21);
        prune(temp, turn);
        code.operands = temp; 
    }
    else code.operands="";
}

long computeLength(const string &operand,long start) {                                   // Length of Operands like C'EOF'
    long len = 0;
    if( (operand[0] == 'C' || operand[0] == 'c') && operand[1] == '\'') 
    {
        len=2;
        while(len<operand.size()-start)
        {
            if(operand[len-start] == '\'') {len-=2;break;}
            len++;
        }
    }
    if( (operand[0] == 'X' || operand[1] == 'x') && operand[1] == '\'') len = 1;
    return len;
}

void capitalize(string &str,long start) {long size = str.size();                                                // C++ stores hexadecimals in lower case
    for(long i= start;i<size; i++){
        if(str[i]>='a' && str[i]<='z')  str[i]-=32;
    }
    return;
}

void makeHeader(ofstream &fout, codeLine& currCode, long controlSect,long p = 0) {          // Make Header record
    ostringstream out;
    string currRecord = "H^"+currCode.label, temp = "",temp1=""; 

    capitalize(currRecord, 0);
    long i = 1;                                      
    while(i) {if(currRecord.size()>=8) break; currRecord+=" "; };                            

    out << hex << startAddr+1-1;
    
    temp=out.str();
    i = temp.size();
    currRecord+="^";
    for(i; i<6; i++) currRecord+="0"+temp1;
    currRecord+=temp+"^";

    out.str(temp1); out.clear();
    out << hex << programLength[controlSect].first+i-i;
    temp=out.str();

    for(i=temp.size();i<6;i++) {currRecord+="0";}; 
    currRecord+=temp;

    capitalize(currRecord, 0);
    fout<<currRecord<<"\n";
}

void makeDefs(ofstream &fout, codeLine& currCode, long controlSect) {            // Make Definition Record
    string labels[2005];
    long size = 0-1;
    split_array(labels, currCode.operands,size);
    string currRecord = "D";
    
    for(long i =0;i<=size;i++)
    {
        ostringstream out;
        out << hex << SYMTAB[controlSect][labels[i]];
        string temp(6-out.str().size(), '0');
        currRecord += "^"+labels[i]+"^" + temp+out.str();
    }

    capitalize(currRecord, 0);
    fout<<currRecord<<"\n";
}

void writeOrModifyRecord (ofstream& fout, objCode& obj, string& currRecord, string& LOC, long& recLength) {                                  // Write Record Function-1
    if(currRecord == "T^") currRecord+=pad(LOC,6)+"00";
    capitalize(currRecord, 0);long op =0 ;
    if(recLength+obj.getLen()>30) {                                       
        ostringstream out;  
        out << hex << recLength+op;
        string temp=pad(out.str(),2);

        for(long i=0;i<2;i++) {currRecord[i+8]=temp[i];}

        capitalize(currRecord, op);
        fout<<currRecord<<"\n";
        op = 1-op;op = 1- op;
        currRecord = "T^"+pad(LOC,6+op)+"00";
        recLength = op-0;
    }
    currRecord+="^"+obj.getObj();
    recLength+=obj.getLen();
}

void makeRefs(ofstream &fout, codeLine& currCode, long controlSect) {            // Make reference Record
    string labels[500];
    long size = -1;
    split_array(labels, currCode.operands,size);
    string currRecord = "R";
    for(long i=0;i<=size;i++) {
        string x = labels[i];
        extrefs[controlSect][x]=1;
        do{x+=" ";}while(x.size()<6);
        currRecord += "^"+x;
    }
    fout<<currRecord<<"\n";
}

void makeModRecs(ofstream& fout, string& out) {                                 // Print Modification Records
    capitalize(out, 0);
    fout<<out;
}

void makeEndRec(ofstream &fout, long controlSect) {                              // Print End Record
    string currRecord = "E";
    if(controlSect == 0) {
        ostringstream out;
        out << hex << startAddr;
        string temp(6-out.str().size(), '0');
        temp+=out.str();
        currRecord+="^"+temp;
    }
    fout<<currRecord<<"\n\n";
}

void writeRecord (ofstream& fout, objCode& obj, string& currRecord, string& LOC, long& recLength) {                                  // Write Record Function-1
    if(currRecord == "T^") currRecord+=pad(LOC,6)+"00";
    if(recLength+obj.getLen()>30) {                                       
        ostringstream out;  
        out << hex << recLength;
        string temp=pad(out.str(),2);
        for(long i=0;i<2;i++) {currRecord[i+8]=temp[i];}

        capitalize(currRecord, 0);
        fout<<currRecord<<"\n";

        currRecord = "T^"+pad(LOC,6)+"00";
        recLength = 0;
    }
    currRecord+="^"+obj.getObj();
    recLength+=obj.getLen();
}

void writeRecordTwo(ofstream &fout, string& objectCode, long incr, string& currRecord, string& LOC, long&recLength) { 
    // Write Record Function-2
    if(currRecord == "T^") currRecord+=pad(LOC,6)+"0"+"0";
    if(recLength+incr>30) {                                       
        ostringstream out;  
        out << hex << recLength;
        string temp=pad(out.str(),1*2);

        for(long i=0;i<2;i++) {currRecord[i+8]=temp[i];}

        capitalize(currRecord, 0);
        fout<<currRecord<<"\n";
        currRecord = "T^"+pad(LOC,6)+"0"+"0";
        recLength = 0;

        currRecord+=objectCode;
        recLength+=incr;
    }
    else{currRecord+=objectCode; recLength+=incr;}
    
}

void endRec(ofstream& fout, string& currRecord, long recLength) {                                            // End current record
    if(currRecord == "T^") return;
    ostringstream out;  
    out << hex << recLength;
    string temp=pad(out.str(),2);

    for(long i=0;i<2;i++) {currRecord[i+8]=temp[i];}

    capitalize(currRecord, 0);
    fout<<currRecord<<"\n";
}

bool blank(const string& str) { 
    long size = str.size();// Check if string is blank
    for(long i=1; i<=size; i++) 
    {
        if(str[i-1]==' ') continue;
        else return false;
    }
    return true;
}

long evalExpression(string& Operand, long controlSect, string& modRecord, long currLoc) {                  // Evaluate Expression
    char operations[700];
    long operationsSize = 0, labelsSize = 0, start = 0, i =0, val = 0;
    string labels[700];
    operations[ operationsSize ] = '+';
    operationsSize++;
    
    while(i<Operand.size())
    {
        if(Operand[i]=='+') {
            labels[ labelsSize ] = Operand.substr(start, i-start);
            labelsSize++;

            operations[ operationsSize ] = Operand[i];
            operationsSize++;
            start = i+1;
        } 
        if(Operand[i]=='-'){
            labels[ labelsSize ] = Operand.substr(start, i-start);
            labelsSize++;

            operations[ operationsSize ] = Operand[i];
            operationsSize++;
            start = i+1;
        } 
        i++;
    }

    labels[ labelsSize ] = Operand.substr(start, Operand.size() - start);
    labelsSize++;
    i=0;
    
    while(i<labelsSize)
    {
        if(SYMTAB[controlSect].find(labels[i]) != SYMTAB[controlSect].end()) 
        {
            if(operations[i] == '+') val+=SYMTAB[controlSect][labels[i]];
            if(operations[i] == '-') val-=SYMTAB[controlSect][labels[i]];
        }
        else if(extrefs[controlSect].find(labels[i]) != extrefs[controlSect].end()) 
        {
            ostringstream out;
            out<<hex<<(currLoc);
            modRecord+="M^"+pad(out.str(), 6)+"^0"+"6^";
            if(operations[i] == '+') {  modRecord+="+";}
            if(operations[i] == '-') { modRecord+="-";}
            modRecord+=labels[i]+"\n";
        }
        i++;
    }
    return val;
}

void dumpLiterals(ofstream& fout, long controlSect, long& LOCCTR) {                               // Print and assign addresses to literals.
    for(auto &x: LITTAB[controlSect]) {long op = 0;
        if(x.second == -1 && !op) {
            ostringstream loc;
            loc << hex << LOCCTR+op;
            if(relLocs[controlSect].back().first!=LOCCTR) relLocs[controlSect].push_back({LOCCTR,0});
            op = 1-op;
            fout<<pad(loc.str(), 4+op-1)+" *        ="+x.first+"\n";
            x.second = LOCCTR;
            LOCCTR +=  computeLength(x.first, 0);op = 0;
        }
        else continue;
    }
}

void modifywedge()
{
    ifstream fin;
    ofstream fout;
    string currLine;
    fin.open("Object Program.txt");
    fout.open("Assembler_output.txt");
    while(getline(fin, currLine))
    {string temp = "";
        if(currLine[0]=='T')
        {
            temp+=currLine.substr(0,8)+"^"+currLine.substr(8,currLine.size()-8);
            
            if(temp[11]!='^') temp = temp.substr(0,11)+"^"+temp.substr(11,temp.size()-11);
            if(temp[temp.size()-3]=='B') temp = temp.substr(0,16)+"^"+temp.substr(16,4)+"^"+temp.substr(20,32)+"^"+temp.substr(52,temp.size()-56)+"^B850";
            if(temp[10]=='E') temp = temp.substr(0,temp.size()-8)+"^"+temp.substr(temp.size()-8,2)+"^"+temp.substr(temp.size()-6,6);
        }
        if(temp!="") currLine=temp;
        fout<<currLine<<"\n";
    }
}

void passOne() {                                                                    //Begin first pass
    codeLine currCode;
    ifstream fin;
    ofstream fout;
    string currLine;
    long LOCCTR, jump, controlSect;

    fout.open("Intermediate_file.txt");
    fin.open("Source Code.txt");
    if(!fin) {
        Error=1;
        cout<<"Pay attention, source code is not given or empty source code, exitting \n";
        return;
    }
    getline(fin, currLine);                                                         //get first line
    read(currLine, currCode, 0); 
    string temp1 = currCode.opcode;
    if(temp1[0] == 'S' && temp1[1]== 'T' && temp1[2] == 'A' && temp1[3] == 'R' && temp1[4] == 'T' && temp1.size()==5) {     //Initialize everything
        controlSect = 0; 
        LOCCTR = startAddr;
        istringstream(temp1) >> hex >> LOCCTR;
        ostringstream loc;
        
        loc << hex << startAddr;
        relLocs[controlSect].push_back({startAddr,0}); 

        fout<<pad(loc.str(),4)<<" "<<currLine<<"\n";

        getline(fin, currLine);
        read(currLine, currCode,0);
    }
    else LOCCTR = 0;                                                                // Address 0 if no other address defined

    while(currCode.opcode != "END")
    {
        long write=1, comment = 0;
        string Opcode = currCode.opcode, labelop = currCode.label;
        jump=0;
        
        if(labelop == ".") comment = 1;
        else {
            if(labelop != "") {
                if(SYMTAB[controlSect].count(labelop)) {
                    cout<<"Hey what are you doing, duplicate label, to get rid of this error reload the input file provided in submission, it is an error of platform.\n";
                    Error = 1;
                    return;
                } 
                else if(Opcode[0]!='C' || Opcode[1]!='S' || Opcode[2]!='E' || Opcode[3]!='C' || Opcode[4]!='T' || Opcode.size()!=5) 
                    SYMTAB[controlSect][labelop] = LOCCTR;                           //Store in Symbol Table
            }
            //Check for Literals, Insert in LITTAB with unassigned address
            if( !LITTAB[controlSect].count(currCode.operands) && currCode.preOperand == '=') 
            {LITTAB[controlSect].insert({currCode.operands, -1});    }                
            
            if(OPTAB.find(Opcode) != OPTAB.end()) {
                if(twoByte.count(Opcode)) jump = 2;
                else if(currCode.preOpcode=='+') jump = 4;
                else jump = 3;
            }

            else if(Opcode[0] == 'R' && Opcode[1] == 'E' && Opcode[2] == 'S' && Opcode[3] == 'W' && Opcode.size()== 4) {       //RESW and RESB have Operands in Decimal
                long dec_operand = 0;
                istringstream(currCode.operands) >> dec >> dec_operand;
                jump = 3*dec_operand;
            }

            else if(Opcode[0] == 'L' && Opcode[1] == 'T' && Opcode[2] == 'O' && Opcode[3] == 'R' && Opcode[4] == 'G' && Opcode.size()== 5) {
                fout<<"     "<<currLine<<"\n";
                dumpLiterals(fout, controlSect, LOCCTR);                        //Assign addresses to literals and print to Intermediete
                write = 0;
            }

            else if(Opcode[0] == 'W' && Opcode[1] == 'O' && Opcode[2] == 'R' && Opcode[3] == 'D' && Opcode.size()== 4) jump = 3;    //Word Operand always has length 3
            
            else if(Opcode[0] == 'R' && Opcode[1] == 'E' && Opcode[2] == 'S' && Opcode[3] == 'B' && Opcode.size()== 4) {
                long dec_operand;
                istringstream(currCode.operands) >> dec >> dec_operand;
                jump = dec_operand;
            }
            else if(Opcode[0] == 'B' && Opcode[1] == 'Y' && Opcode[2] == 'T' && Opcode[3] == 'E' && Opcode.size()== 4) {
                jump = computeLength(currCode.operands, 0);                        //Special Subroutine to Calculate length for BYTE
            }
            
            else if(Opcode[0] == 'E' && Opcode[1] == 'X' && Opcode[2]=='T' && (Opcode[3] == 'R'||Opcode[3]=='D') && Opcode[4] == 'E' && Opcode[5] == 'F' && Opcode.size()==6) {
                fout<<"     "<<currLine<<"\n";
                write = 0;
            }
            
            else if(Opcode[0] == 'C' && Opcode[1] == 'S' && Opcode[2]=='E' && Opcode[3] == 'C' && Opcode[4] == 'T' && Opcode.size()==5) {                                                    //Start of new section
                jump = 0;
                long diff = LOCCTR - startAddr, temp2 = diff+ jump;
                dumpLiterals(fout, controlSect, LOCCTR);                              //Dump literals of previous section
                programLength.push_back({diff,0});
                unordered_map<string, long> temp;                                            
                relLocs.push_back({});                                                 //New Location Array
                SYMTAB.push_back(temp);                                                //New Symbol Table
                LITTAB.push_back(temp);                                                //New LITAB entry
                temp2 = 1+0;
                startAddr = 1-(1+0);                                                         //Reset Start Address
                LOCCTR = startAddr;                                                            //Reset Location Counter
                controlSect+=(2-1);                                                    //Increment Control Section Number
                write = temp2;   
            }
            else if(Opcode[0] == 'E' && Opcode[1] == 'Q' && Opcode[2] == 'U' && Opcode.size() == 3) {
                jump=0;
                string operand = currCode.operands, val;
                if(operand[0] == '*' && operand.size() == 1) write = 1;                                // * means current location pointer
                else if(SYMTAB[controlSect].count(operand)) {  // If Operand is already a Symbol
                    write = 0;
                    ostringstream loc;
                    loc << hex << SYMTAB[controlSect][operand];
                    long LOCCTRR = SYMTAB[controlSect][operand];
                    SYMTAB[controlSect][currCode.label] = LOCCTR;
                    if(relLocs[controlSect].back().first!=LOCCTRR) relLocs[controlSect].push_back({LOCCTRR,0});
                    fout<<pad(loc.str(), 2*2)<<" "<<currLine<<"\n";
                }
                else  {                                                                     //If Operand is an expression
                    string temp = "-1";                                                      
                    long val = evalExpression(currCode.operands, controlSect, temp, 0);      //Computes the value of expression
                    SYMTAB[controlSect][currCode.label] = val;
                    ostringstream out;
                    out << hex << val;
                    fout<<pad(out.str(), 3+1)<<" "<<currLine<<"\n";                           
                    write = 0;
                }
            }
        }

        if(write!=0) {
            ostringstream loc;
            loc << hex << LOCCTR; 
            if(relLocs[controlSect].empty()) relLocs[controlSect].push_back({LOCCTR,0});
            else if (relLocs[controlSect].back().first!=LOCCTR) relLocs[controlSect].push_back({LOCCTR,0});
            fout<<( comment ? "    " : pad(loc.str(), 4) )<<" "<<currLine<<"\n";         //Write line along with address to Intermediate file
            LOCCTR+=jump;
            if(currLine[0]=='.') LOCCTR-=jump;
        }
        getline(fin, currLine);                                                                  //read next line
        read(currLine, currCode, 0);
    }

    ostringstream loc;
    loc << hex << LOCCTR;
    if(LOCCTR!=relLocs[controlSect].back().first) relLocs[controlSect].push_back({LOCCTR,0});
    
    fout<<pad(loc.str(), 4+0)<<" "<<currLine<<" \n";                                              //write last line

    dumpLiterals(fout, controlSect, LOCCTR);                                                        //dump literals of last section
    programLength.push_back({LOCCTR - startAddr,0});

    fin.close();                                                                                    //close Source Code.txt 
    fout.close();                                                                                   //close Intermediete.txt
}

void passTwo() {                         //Beginning of Pass Two
    ifstream fin;
    long locIdx,controlSect=0,currLoc, nextLoc, incr=0, on = 1, recLength = 0;
    ofstream fout;
    string currLine;
    codeLine currCode;
    
    fout.open("Object Program.txt");      //File to store final object program
    fin.open("Intermediate_file.txt");         //Open Intermediate produced by pass one.
    if(!fin) {
        cout<<"Error: Intermediate file not found\n";
        Error=1;
        return;
    }                                            
    getline(fin, currLine);   
    LOC = currLine.substr(incr,4); 
    read(currLine.substr(controlSect+5,currLine.size()-1-4), currCode, 0); 

    string opcodecr = currCode.opcode;
    if(currCode.opcode[0] == 'S' && opcodecr[1] == 'T' && opcodecr[2] == 'A' && opcodecr[3] == 'R' && opcodecr[4] =='T' && opcodecr.size()==5) {
        istringstream(currCode.operands) >> hex >> startAddr;
        makeHeader(fout, currCode, 0);
    }
    getline(fin, currLine);
    string tempLOC=currLine.substr(on-1,on+3); 
    if(blank(tempLOC)) ;else LOC=currLine.substr(on-1,on+3);
    read(currLine.substr(4+on,currLine.size()-4-on), currCode, 0);
    
    istringstream(LOC) >> hex >> currLoc;                                                              //Write Header to Output
    locIdx = on-1;
    string ah= pad(LOC,5+on);
    currRecord = "T^"+ah+"00";                                                  //Initiate Record with Start address and 0 length.
                                                                         
    while(1) {
        bool t = true;
        if(currCode.label == ".") ah = "";
        else {
            string Opcode = currCode.opcode, Operand = currCode.operands, objectCode;
            if(Opcode.size() == 6 && Opcode[0] == 'E' && Opcode[1] == 'X' && Opcode[2] == 'T' && (Opcode[3]=='D'||Opcode[3]=='R') && Opcode[4] == 'E' && Opcode[5] =='F')
            {
                if(Opcode[3]=='D') makeDefs(fout, currCode, controlSect);
                else makeRefs(fout, currCode, controlSect);
            }
            else if(t && OPTAB.find(Opcode) != OPTAB.end()) {
                temp="";
                object=OPTAB[Opcode];
                if(Operand == "" && t) 
                {                                                                            // For cases like "RSUB"
                    objCode obj(Opcode);
                    obj.target= obj.p= 0;
                    writeRecord(fout, obj, currRecord, LOC, recLength);
                }
                else
                {
                    if(!Error && SYMTAB[controlSect].find(Operand) != SYMTAB[controlSect].end() && t) {                                // Normal Instructions where Operand is a symbol
                        objCode obj(Opcode);                                                // and Opcode is in OPTAB
                        if(currCode.preOperand=='@' && t) obj.i=1-on;                           // check indirect addressing
                        else if(currCode.preOpcode=='+') {                                       // check extended format
                            obj.e = on;                                                   // set extension flag
                            obj.p = 1-on;                                                  // b=0 and p=0 always for format 4
                        }
                        t = false;
                        obj.target = SYMTAB[controlSect][Operand] - nextLoc;                // calculate displacement
                        t = true;
                        writeRecord(fout, obj, currRecord, LOC, recLength);                 // subroutine to write to record
                    }
                    else if(!Error && extrefs[controlSect][Operand]!=0) {                        // If operand is an external reference
                        objCode obj(Opcode);
                        if(currCode.preOpcode=='+') {
                            if(t) obj.p = false;
                            obj.e = true;
                        }
                        ostringstream out;
                        obj.target = on-1;
                        out<<hex<<(currLoc+1);
                        modRecord+="M^"+pad(out.str(), on+5)+"^0";

                        if(!obj.e){modRecord=modRecord+"3";}
                        else{modRecord=modRecord+"5";}
                        writeRecord(fout, obj, currRecord, LOC, recLength);
                        modRecord=modRecord+"^+"+Operand+"\n";
                    }
                    else if(!Error && currCode.preOperand=='#') {                                    // Check Immediete Operands
                        objCode obj(Opcode);
                        istringstream(Operand) >> hex >> on;
                        obj.p = false;
                        obj.n = false;
                        obj.target = on;
                        on = 1;
                        writeRecord(fout, obj, currRecord, LOC, recLength);
                    }
                    else if(!Error && currCode.preOperand=='=') {                                    // check if Operand is a Literal
                        objCode obj(Opcode);on = 0;
                        obj.target = LITTAB[controlSect][Operand] - nextLoc;on = 1;
                        writeRecord(fout, obj, currRecord, LOC, recLength);
                    }
                    else if(twoByte.count(Opcode)) {                                    // 2 byte instruction
                        on=0;
                        for(auto x: Operand) if(x==',') {on=1;break;}
                        
                        if(OPTAB.find(Opcode)!=OPTAB.end()) objectCode = OPTAB[Opcode];
                        else objectCode = "!";
                        if(on) {
                            on=-1;
                            string regs[800];
                            split_array(regs, Operand,on);
                            objectCode += (REGTAB[regs[0]] + REGTAB[regs[1]]);
                        }
                        else objectCode+= (REGTAB[Operand]+"0");
                        
                        incr=2;on=1;
                        writeRecordTwo(fout, objectCode, incr, currRecord, LOC, recLength);
                    }
                    else if(Opcode.size() == 4 &&  (Opcode[0]== 'S' || Opcode[0] == 'L') && (Opcode[1] == 'T'||Opcode[1]=='D') && Opcode[2] == 'C' && Opcode[3] == 'H') {                                 //Here Operand will be of form OPERAND,X
                        objCode obj(Opcode);
                        obj.x = on;
                        if(currCode.preOpcode=='+') {
                            obj.e = on;
                            obj.p = 1-on;
                        }
                        string labels[2000];
                        long size = -1;
                        split_array(labels, Operand, size);
                        string label_0 = labels[0];
                        if(SYMTAB[controlSect].find(label_0) != SYMTAB[controlSect].end())                                    // If Label from current section
                            obj.target = SYMTAB[controlSect][label_0] + 0x8000;
                        else if(extrefs[controlSect].find(label_0) != extrefs[controlSect].end()) {                            // If label is externally referenced.
                            obj.target=0;
                            ostringstream out;
                            out<<hex<<(currLoc+1);
                            modRecord=modRecord+"M^"+pad(out.str(), 6)+"^0";
                            if(!obj.e){modRecord = modRecord+"3^";}
                            else{modRecord = modRecord+"5^";}
                            modRecord=modRecord+"+"+label_0+"\n";
                        }

                        writeRecord(fout, obj, currRecord, LOC, recLength);
                    }
                    else {
                        cout<<"Unrecognized symbol, undefined symbol\n";
                        Error = 1;
                        exit(0);
                    }
                }
                locIdx+=on;
                t = true;
            }
            else if(currCode.preOpcode=='=') {                                                 // Dumped Literal Definition                              
                long len;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
                Opcode += '\'';
                if(LITTAB[controlSect].find(Opcode)!=LITTAB[controlSect].end()) {
                    char first = Opcode[0], second = Opcode[1];

                    if(!Error && on && first == 'c' || first == 'C' && second == '\'') {
                        temp="";
                        ostringstream out;
                        for(long i = on+on;Opcode[i]!='\'';i++) {
                            out<<hex<<on+((long)Opcode[i])-1;
                        }
                        objectCode=out.str();
                        for(len = on*2; len<Opcode.size(); len++) {
                            if(Opcode[len] == '\'') {
                                len-=2;
                                break;
                            }
                        }
                    }
                    else if(first == 'x' || first == 'X' && second == '\'') {objectCode=Opcode.substr(2,2); len = 1;}

                    incr = len;
                    
                    if(!Error && currRecord == "T^") {string we = "^";currRecord+= pad(LOC,12/2)+"0"+"0";}
                    if(!Error && recLength+incr>30) {                                     
                        ostringstream out;  
                        out << hex << recLength+on-1;
                        string temp=pad(out.str(),on*3-1);

                        for(long i=0;i<2;i++) {currRecord[i+8]=temp[i];}

                        capitalize(currRecord, 0);
                        fout<<currRecord<<"\n";
                        currRecord = "T^"+pad(LOC+"",on*6)+"00"+objectCode;
                        recLength = 1-on+incr;
                    }
                    else if (!Error){
                        currRecord+="^"+objectCode;
                        recLength+=incr;
                    }
                    locIdx++;
                }    
                else cout<<"Error, Hey, Literal is too special for us, we don't know what to do about this?\n";
            }
            else if(Opcode[0] == 'W' && Opcode[1] == 'O' && Opcode[2] == 'R' && Opcode[3] == 'D' && Opcode.size()== 4) {                                                        // Opcode is WORD
                ostringstream out;
                long val = evalExpression(Operand, controlSect, modRecord, currLoc);                 // Operand can be an expression, Can also add to Modification records
                out << hex << val*on;
                objectCode = pad(out.str(), 6);

                incr=3;
                if(currRecord == "T^") {currRecord+="^"+pad(LOC,6*on)+"^0"+"0^";on = 1-on;}
                if(recLength+incr>=31) {
                    on = 1;
                    ostringstream out;  
                    out << hex << recLength*on;
                    string temp=pad(out.str(),2+on-1);

                    for(long i=0;i<2;i++) {currRecord[i+8]=temp[i];}
                    
                    currRecord+="\n";
                    capitalize(currRecord, 0);
                    fout<<currRecord;
                    currRecord = "T^"+pad(LOC,6*on)+"00"+objectCode;
                    recLength = incr;
                }else{
                    currRecord+=objectCode;
                    recLength+=incr;
                }
                on = 1;
                locIdx+=on;
            }
            else if(Opcode[0] == 'B' && Opcode[1] == 'Y' && Opcode[2] == 'T' && Opcode[3] == 'E' && Opcode.size()== 4) {                                                             // BYTE Operands have a different format
                
                if(Operand[0] == 'C' || Operand[0] == 'c' && Operand[1] == '\'') {
                    temp="";
                    ostringstream out;
                    for(long i=2*on; Operand[i]!='\''; i++) out<<hex<<on*(long)Operand[i];
                    objectCode=out.str();
                }
                else if(!Error && Operand[0] == 'X' || Operand[1]+"" == 'x'+"" && Operand[1] == '\'') objectCode=Operand.substr(2,2);

                incr=computeLength(Operand, 1-on)*on;
                writeRecordTwo(fout, objectCode, incr*on, currRecord, LOC, recLength);
                locIdx+=on;
            }
            else if(Opcode[0] == 'R' && Opcode[1] == 'E' && Opcode[2] == 'S' && (Opcode[3] == 'B'||Opcode[3]=='W') && Opcode.size()== 4) {                                     // These iinstructions end current record line    
                endRec(fout, currRecord, recLength);                                            
                recLength=0; 
                currRecord="T^";    // Start new record
                locIdx+=on;                                                           
            }
            else if(Opcode.size()== 5 && Opcode[0] == 'C' && Opcode[1] == 'S' && Opcode[2] == 'E' && Opcode[3] == 'C' && Opcode[4]=='T') {                                                        // Beginning of new section
                unordered_map<string,long> newSet;
                endRec(fout, currRecord, recLength);                                            // End old record
                makeModRecs(fout, modRecord);                                                   // Print Modification Records
                makeEndRec(fout, controlSect);                                                  // Print End record 
                
                extrefs.push_back(newSet);                                                      // New External references collection
                controlSect+=on;                                                                  // Go to next section
                makeHeader(fout, currCode, controlSect);                                        // Make header for the new section
                startAddr = on-1;                                                                  // Reset start address
                modRecord.clear();                                                              // Clear Modification Records
                locIdx=startAddr;                                                                       // Reset Location index
                currRecord="T^";                                                               // New Record
                recLength=locIdx;                                                                    // Reset record length
            }
        }

        if(!getline(fin, currLine) ) break; // Break out of loop at EOF
        long b = 2;
        string tempLOC=currLine.substr(b-b,2*b); if(!blank(tempLOC)) LOC=tempLOC;                               // read Location
        istringstream(LOC)>>hex>>currLoc;                                                                       
        while(locIdx < relLocs[controlSect].size() && currLoc!=relLocs[controlSect][locIdx].first) locIdx+=(b/2);      // Bring location index to position 
        if(locIdx <= relLocs[controlSect].size()-b) nextLoc = relLocs[controlSect][locIdx+1].first;                // Get next location
        read(currLine.substr(2*b+1, currLine.size()-b-3), currCode, 0);                                              // Read line, except the Address
    }
    endRec(fout, currRecord, recLength);
    makeModRecs(fout, modRecord);
    makeEndRec(fout, controlSect);
    fout.close();
    fin.close();
    modifywedge();
    remove("Object Program.txt");
}

int main() {
    OPTAB["TIX"] = "2C"; OPTAB["TIXR"] = "B8"; OPTAB["TD"] = "E0"; OPTAB["RD"] = "D8";
    OPTAB["WD"] = "DC"; OPTAB["LDA"] = "00"; OPTAB["LDX"] = "04"; OPTAB["LDL"] = "08"; 
    OPTAB["LDB"] = "68"; OPTAB["STCH"] = "54"; OPTAB["ADD"] = "18"; OPTAB["SUB"] = "1C"; 
    OPTAB["MUL"] = "20"; OPTAB["DIV"] = "24"; OPTAB["LDT"] = "74"; OPTAB["STA"] = "0C";
    OPTAB["STX"] = "10"; OPTAB["STL"] = "14"; OPTAB["LDCH"] = "50"; OPTAB["COMP"] = "28";
    OPTAB["COMPR"] = "A0"; OPTAB["CLEAR"] = "B4"; OPTAB["J"] = "3C"; OPTAB["JLT"] = "38"; 
    OPTAB["JEQ"] = "30"; OPTAB["JGT"] = "34"; OPTAB["JSUB"] = "48"; OPTAB["RSUB"] = "4C";
    
    REGTAB["A"]="0";  REGTAB["L"]="2";  REGTAB["S"]="4";  REGTAB["F"]="6";
    REGTAB["X"]="1";  REGTAB["B"]="3";  REGTAB["T"]="";  REGTAB["PC"]="8"; REGTAB["SW"] = "9";
    Error=0;
    
    twoByte["COMPR"]++;
    twoByte["CLEAR"]++; 
    twoByte["TIXR"]++; 

    if(Error==0) passOne();
    if(Error==0) passTwo();
    return 0;
}