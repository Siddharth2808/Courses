CREATE PROCEDURE tt_violation()
BEGIN

SELECT DISTINCT temp1.roll_number,temp1.`name`,temp1.cid,temp2.cid 
FROM (SELECT cwsl.roll_number, cwsl.`name`, cwsl.cid, ett.exam_date, ett.start_time, ett.end_time, cwsl.serial_number FROM cwsl INNER JOIN ett ON cwsl.cid=ett.cid ) AS temp1 
INNER JOIN 
(SELECT cwsl.roll_number, cwsl.`name` ,cwsl.cid, ett.exam_date, ett.start_time, ett.end_time, cwsl.serial_number FROM cwsl INNER JOIN ett ON cwsl.cid = ett.cid) AS temp2 
ON temp1.roll_number = temp2.roll_number 
WHERE (temp1.exam_date = temp2.exam_date 
AND  temp1.start_time = temp2.start_time 
AND   temp1.serial_number < temp2.serial_number );

END 
//

DELIMITER ;