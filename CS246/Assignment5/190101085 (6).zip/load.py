import mysql.connector
from mysql.connector import Error
import csv
import os
import shutil
import pathlib

try:
	mydb = mysql.connector.connect(
		host='localhost',
		user='root',
		password='ss2500$',
		database='assignment05'
	)
	if mydb.is_connected():
		print("Connected to Database : " + mydb.database)
except Error as e:
	print(e)
	exit()
cursor=mydb.cursor()
cursor.execute('SHOW TABLES')
for (t,) in cursor:
	print(t)
print("Sarting csv file fetching")
rootdir = 'C:/Users/siddharth/Downloads/assignment05/assignment05/database-15-feb-2021/course-wise-students-list/'
records=0
files_num=0
for subdir, dirs, files in os.walk(rootdir):
	for file in files:
		if file.endswith('.csv'):
			files_num = files_num + 1
			csv_data = csv.reader(open(os.path.join(subdir,file)),delimiter=',')
			for row in csv_data:
				temp=row
				temp.append(os.path.splitext(file)[0])
				records = records + 1
				try:
					cursor.execute('INSERT INTO cwsl (serial_no,roll_no,sname,email,cid) VALUES(%s,%s,%s,%s,%s)', temp)
				except Error as e:
					records = records-1
					print(e)
				
mydb.commit()
print("Added " + str(records) + " records from " + str(files_num)+" files")	
cursor.close()
mydb.close()
print("Connection closed to Server")
