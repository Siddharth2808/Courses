CREATE DATABASE assignment05;
USE assignment05;
CREATE TABLE ett (
cid VARCHAR(200) PRIMARY KEY,
exam_date VARCHAR(200),
start_time VARCHAR(200),
end_time VARCHAR(200)
);
CREATE TABLE cc (
cid VARCHAR(200) PRIMARY KEY,
credits VARCHAR(200)
);
CREATE TABLE cwsl(
   serial_number VARCHAR(200),
   cid VARCHAR(200) PRIMARY KEY,
   roll_number VARCHAR(200),
   `name` VARCHAR(200),
   email VARCHAR(200)
);



LOAD DATA LOCAL INFILE 'C:/Assignments/cs246/lab5/assignment5/database-15-feb-2021/course-credits.csv' INTO TABLE cc FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n';
LOAD DATA LOCAL INFILE 'C:/Assignments/cs246/lab5/assignment5/database-15-feb-2021/exam-time-table.csv' INTO TABLE ett FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n';
