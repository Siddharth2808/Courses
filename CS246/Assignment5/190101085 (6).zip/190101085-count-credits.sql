DELIMITER //
CREATE PROCEDURE count_credits()
BEGIN
SELECT cwsl.roll_number, cwsl.`name`, SUM(cc.credits)
FROM cwsl
INNER jOIN cc
ON cwsl.cid = cc.cid
GROUP BY roll_number
HAVING SUM(cc.credits) > 40;
END;
//
DELIMITER ;